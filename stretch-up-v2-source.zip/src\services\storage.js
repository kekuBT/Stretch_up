export const STORAGE_KEY = 'stretch-up-v2';

export const defaultPreferences = {
  voice: true,
  sound: true,
  animations: true,
  theme: 'system',
  tracking: true,
  reduceMotion: false,
  preparationSeconds: 5,
  completed: [],
  custom: []
};

export function loadState(storage = globalThis.localStorage) {
  if (!storage) return {...defaultPreferences};
  try {
    const current = JSON.parse(storage.getItem(STORAGE_KEY) || '{}');
    const legacy = JSON.parse(storage.getItem('stretch-up-v1') || '{}');
    return {...defaultPreferences, ...legacy, ...current};
  } catch {
    return {...defaultPreferences};
  }
}

export function saveState(value, storage = globalThis.localStorage) {
  if (!storage) return false;
  try { storage.setItem(STORAGE_KEY, JSON.stringify(value)); return true; }
  catch { return false; }
}

export function clearProgress(state) {
  return {...state, completed: []};
}

export function saveCustomRoutine(state, routine) {
  const custom = state.custom.filter(item => item.id !== routine.id);
  return {...state, custom: [...custom, routine]};
}

export function duplicateCustomRoutine(state, routine, now = Date.now()) {
  return saveCustomRoutine(state, {...routine, id: `custom-${now}`, name: `${routine.name} copy`});
}

export function deleteCustomRoutine(state, id) {
  return {...state, custom: state.custom.filter(item => item.id !== id)};
}
