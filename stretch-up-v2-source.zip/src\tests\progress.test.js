import {describe,it,expect} from 'vitest';
import {progressSummary} from '../utils/progress.js';
describe('progress calculations',()=>{
 it('calculates minutes, streaks, favorite and recent sessions',()=>{const d=x=>Date.parse(`2026-07-${x}T12:00:00Z`);const result=progressSummary([{at:d('17'),id:'a',mins:5},{at:d('18'),id:'b',mins:10},{at:d('19'),id:'a',mins:5}],d('20'));expect(result).toMatchObject({sessions:3,minutes:20,currentStreak:3,longestStreak:3,favorite:'a'});});
 it('returns zero current streak after a gap',()=>expect(progressSummary([{at:Date.parse('2026-07-01'),id:'a',mins:5}],Date.parse('2026-07-20')).currentStreak).toBe(0));
});
