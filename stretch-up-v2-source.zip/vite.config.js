import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  base: '/Stretch_up/',
  plugins: [react(), VitePWA({
    registerType: 'autoUpdate',
    manifest: { name: 'Stretch Up', short_name: 'Stretch Up', description: 'Calm, guided daily stretching.', theme_color: '#173f35', background_color: '#f4f1e8', display: 'standalone', scope: '/Stretch_up/', start_url: '/Stretch_up/', icons: [{ src: 'icon-192.svg', sizes: '192x192', type: 'image/svg+xml', purpose: 'any' }, { src: 'icon-512.svg', sizes: '512x512', type: 'image/svg+xml', purpose: 'any maskable' }] }
  })],
  test: { environment: 'node' }
});
