export {stretches} from '../data.js';
export const bodyAreas = ['Neck','Shoulders','Chest','Upper back','Lower back','Wrists and forearms','Hips','Glutes','Hamstrings','Quadriceps','Calves','Ankles and feet','Full body'];
