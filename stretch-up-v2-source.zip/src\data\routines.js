export {routines,totalDuration} from '../data.js';
