import {describe,it,expect} from 'vitest';
import {remainingMs,nextStep,sessionProgress,isComplete,skipStep} from './session.js';
describe('session timing',()=>{
 it('uses timestamps and never returns negative time',()=>{expect(remainingMs(5000,3000)).toBe(2000);expect(remainingMs(5000,6000)).toBe(0)});
 it('preserves paused remaining time',()=>expect(remainingMs(99,999,4200)).toBe(4200));
 it('switches sides before advancing',()=>{expect(nextStep(1,'left',{sides:true})).toEqual({index:1,side:'right'});expect(nextStep(1,'right',{sides:true})).toEqual({index:2,side:'left'})});
 it('calculates bounded progress',()=>expect(sessionProgress(1,15,30,4)).toBe(.375));
 it('handles skipping and completion',()=>{expect(skipStep(0,'left',{sides:false},1)).toMatchObject({index:1,complete:true});expect(isComplete(2,2)).toBe(true)});
});
