# Stretch Up

Stretch Up is a calm, mobile-first guided stretching progressive web app. It is designed for a tired user who wants to choose a short routine, press Start, and follow clear visual, spoken, and timed cues without memorizing movements.

> Stretching should feel like gentle-to-moderate tension—not sharp pain. Stop for numbness, tingling, dizziness, instability, or joint pinching. Never bounce or force range. People with injuries or medical restrictions should follow qualified professional advice. Stretch Up provides general wellness guidance, not medical treatment.

## Features

- A prominent 10-minute full-body daily routine
- Quick Reset, Upper-Body Relief, Lower-Body Relief, and Relax Before Bed routines
- Searchable, body-area-filtered stretch library
- Individual guided stretch practice
- Structured form, breathing, modification, and safety guidance
- Slow SVG demonstrations with body-area highlights, motion cues, pause, and reduced-motion handling
- Timestamp-based guided player with side switching, spoken cues, gentle sounds, fullscreen, wake lock, and keyboard controls
- Locally saved custom routines with accessible reorder controls
- Private on-device session history, minutes, current streak, longest streak, and most-used routine
- Light/dark themes, progress opt-out, and reduced-motion preference
- Installable PWA with an offline application shell
- GitHub Pages-compatible `/Stretch_up/` asset base

## Preview

The home experience recommends one routine immediately and shows duration, target area, and a direct start action. The player is optimized for phone use with a large demonstration, circular timer, concise active cue, upcoming stretch, and large transport controls.

Screenshots should be added after the first browser QA pass at approximately 390 × 844 and 1440 × 900.

## Technology

- React
- Vite
- CSS without a component-framework dependency
- Vitest for deterministic logic tests
- `vite-plugin-pwa` for manifest generation, service-worker updates, and offline caching
- Browser Speech Synthesis, Web Audio, Fullscreen, and Screen Wake Lock APIs with graceful fallbacks
- `localStorage`; no account, backend, paid API, analytics, or secrets

## Local setup

Use Node.js 20 or later.

```bash
npm install
npm run dev
```

## Development commands

```bash
npm run dev      # local development server
npm test         # automated logic tests
npm run build    # production output in dist/
npm run preview  # preview the production build
```

## Testing

Tests cover timestamp remaining-time calculations, pause preservation, side switching, routine advancement and completion, skipping, progress summaries, streaks, custom routine CRUD, preference persistence, and progress clearing.

Manual release review should cover:

- Pause/resume after backgrounding the browser
- Automatic left/right switching and completion
- Voice and sound enabled and disabled
- Screen Wake Lock and fullscreen fallbacks
- Keyboard controls: Space, Left/Right arrows, and Escape
- Focus order and visible focus indicators
- Reduced-motion system and app preferences
- Custom routine save/reload behavior
- Phone and desktop layouts
- Install and offline reload

## Production build and GitHub Pages

`vite.config.js` uses `base: '/Stretch_up/'`, and the PWA manifest uses the same start URL and scope. The interface uses in-memory navigation rather than history routes, avoiding GitHub Pages deep-link 404s.

The workflow in `.github/workflows/deploy.yml` installs dependencies, runs tests, builds, uploads `dist`, and deploys to GitHub Pages after changes reach `main`. Configure **Repository Settings → Pages → Source** as **GitHub Actions**. The intended URL is:

`https://kekubt.github.io/Stretch_up/`

## Content maintenance

### Add a stretch

Add a record to `src/data.js` with a stable `id`, `name`, `areas`, `position`, concise `steps`, `feel`, `avoid`, `mistake`, `breath`, `easy`, optional `hard`, `duration`, `sides`, `motion`, and a stretch-specific `caution` where appropriate. Add an optional reputable `video` URL only when a simplified illustration cannot communicate the position safely.

### Add a routine

Add a routine through the `make` helper in `src/data.js`. Include its stable ID, display name, intended duration, ordered stretch IDs, purpose, intensity, and equipment. Confirm the actual timed sequence remains close to the displayed duration.

### Modify illustrations

Pose definitions live in `src/components/AnimatedStretch.jsx`. Each pose defines head placement, torso and limb paths, a subdued ghost position, and a motion arrow. Keep the style consistent and validate that the result cannot be interpreted as unsafe form. `prefers-reduced-motion` and the app preference freeze the illustration.

## Project organization

- `src/components/` — reusable demonstrations and safety UI
- `src/data/` — stable data entry points
- `src/services/` — local persistence
- `src/utils/` — timer and progress calculations
- `src/tests/` — persistence and progress tests
- `public/` — install icons

## Known limitations

- Simplified SVG figures are guidance aids, not biomechanical models; complex movements should link to reputable supplemental video.
- Speech voice, Wake Lock, and Fullscreen behavior varies by browser and platform.
- Progress and custom routines remain on the current browser/device and are not synchronized.
- Browser visual QA and the production build must be completed in an environment where npm dependencies can be installed.
