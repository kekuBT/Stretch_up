import {useId} from 'react';

const poses = {
  tilt:{torso:'M100 80 L100 170',head:[86,45],arms:['M98 95 L60 145','M102 95 L140 145'],legs:['M98 168 L72 232','M102 168 L130 232'],ghost:'rotate(-12 100 165)',arrow:'M55 38 Q82 18 112 35'},
  side:{torso:'M100 80 Q118 125 105 170',head:[82,44],arms:['M98 92 Q70 58 70 25','M103 92 L145 128'],legs:['M103 168 L82 232','M106 168 L140 230'],ghost:'rotate(-10 100 165)',arrow:'M58 42 Q88 14 120 35'},
  lunge:{torso:'M105 80 L105 170',head:[91,44],arms:['M103 98 L72 142','M107 98 L138 142'],legs:['M105 168 L55 220','M105 168 L162 195'],ghost:'translate(-12 0)',arrow:'M48 188 L82 188'},
  fold:{torso:'M98 80 Q110 125 145 152',head:[78,44],arms:['M105 105 L160 180','M100 108 L145 188'],legs:['M100 168 L72 232','M103 168 L145 228'],ghost:'rotate(-18 100 165)',arrow:'M142 86 Q172 120 168 156'},
  open:{torso:'M100 80 L100 170',head:[86,44],arms:['M98 100 L55 132','M102 100 L148 130'],legs:['M98 168 L75 232','M102 168 L130 232'],ghost:'translate(0 8)',arrow:'M62 112 L38 112 M138 112 L162 112'},
  reach:{torso:'M100 80 L100 170',head:[86,44],arms:['M98 102 L50 105','M102 102 L150 105'],legs:['M98 168 L75 232','M102 168 L130 232'],ghost:'translate(8 0)',arrow:'M45 82 L22 82 M155 82 L178 82'},
  roll:{torso:'M100 80 L100 170',head:[86,44],arms:['M98 102 L62 150','M102 102 L138 150'],legs:['M98 168 L75 232','M102 168 L130 232'],ghost:'translate(0 8)',arrow:'M55 85 Q100 55 145 85'},
  default:{torso:'M100 80 L100 170',head:[86,44],arms:['M98 102 L62 150','M102 102 L138 150'],legs:['M98 168 L75 232','M102 168 L130 232'],ghost:'translate(6 0)',arrow:'M45 70 L70 70'}
};

export default function AnimatedStretch({stretch,paused=false,large=false,reduceMotion=false}) {
  const id=useId().replaceAll(':',''); const pose=poses[stretch.motion]||poses.default; const still=paused||reduceMotion;
  return <figure className={`svg-demo ${large?'demo-large':''} ${still?'still':''}`} aria-label={`Demonstration: ${stretch.name}`}>
    <svg viewBox="0 0 200 260" role="img" aria-labelledby={`${id}-title ${id}-desc`}>
      <title id={`${id}-title`}>{stretch.name}</title><desc id={`${id}-desc`}>{stretch.steps.join(' ')}</desc>
      <g className="ghost" transform={pose.ghost}><circle cx={pose.head[0]} cy={pose.head[1]} r="14"/><path d={pose.torso}/>{pose.arms.map(x=><path key={x} d={x}/>)}{pose.legs.map(x=><path key={x} d={x}/>)}</g>
      <g className="person"><circle cx={pose.head[0]} cy={pose.head[1]} r="14"/><path d={pose.torso}/>{pose.arms.map(x=><path key={x} d={x}/>)}{pose.legs.map(x=><path key={x} d={x}/>)}</g>
      <path className="motion-arrow" d={pose.arrow}/><path className="arrow-head" d="M0 0 l-8 -5 v10 z"/>
      <circle className="body-highlight" cx="100" cy={stretch.areas.includes('Hips')?155:stretch.areas.includes('Neck')?67:stretch.areas.includes('Lower back')?130:105} r="24"/>
    </svg><figcaption>{stretch.areas[0]}</figcaption>
  </figure>
}
