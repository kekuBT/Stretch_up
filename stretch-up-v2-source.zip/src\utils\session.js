export function remainingMs(endAt, now, pausedRemaining = null) { return Math.max(0, pausedRemaining ?? endAt - now); }
export function nextStep(index, side, item) { return item?.sides && side === 'left' ? {index, side:'right'} : {index:index+1, side:'left'}; }
export function previousStep(index) { return {index:Math.max(0,index-1), side:'left'}; }
export function sessionProgress(index, elapsed, duration, count) { return count ? Math.min(1,(index+Math.min(1,elapsed/duration))/count) : 0; }
export function isComplete(index, count) { return index >= count; }
export function skipStep(index, side, item, count) { const next=nextStep(index,side,item); return {...next, complete:isComplete(next.index,count)}; }
