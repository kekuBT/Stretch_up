const dayKey = value => new Date(value).toISOString().slice(0, 10);
const dayNumber = value => Math.floor(new Date(`${dayKey(value)}T00:00:00Z`).getTime() / 86400000);

export function progressSummary(completed, now = Date.now()) {
  const sessions = [...completed].sort((a,b) => a.at - b.at);
  const days = [...new Set(sessions.map(item => dayKey(item.at)))].map(dayNumber).sort((a,b)=>a-b);
  let longest = 0, run = 0, previous;
  for (const day of days) { run = previous != null && day === previous + 1 ? run + 1 : 1; longest = Math.max(longest, run); previous = day; }
  const today = dayNumber(now), last = days.at(-1);
  let current = last != null && today - last <= 1 ? 1 : 0;
  if (current) for (let i=days.length-1;i>0 && days[i]-days[i-1]===1;i--) current++;
  const counts = sessions.reduce((map,item)=>({...map,[item.id]:(map[item.id]||0)+1}),{});
  const favorite = Object.entries(counts).sort((a,b)=>b[1]-a[1])[0]?.[0] || null;
  return {sessions:sessions.length, minutes:sessions.reduce((sum,item)=>sum+(item.mins||0),0), currentStreak:current, longestStreak:longest, favorite, recent:sessions.slice(-8).reverse()};
}
